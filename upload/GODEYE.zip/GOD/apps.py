from django.apps import AppConfig


class GodConfig(AppConfig):
    name = 'GOD'
